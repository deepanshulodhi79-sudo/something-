import { useState } from "react";

export default function App() {
  const [form, setForm] = useState({
    senderName: "",
    senderMail: "",
    appPassword: "",
    subject: "",
    message: "",
    recipients: ""
  });
  const [status, setStatus] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const sendMail = async () => {
    setStatus("sending");
    const res = await fetch("https://YOUR-BACKEND-URL.up.railway.app/send-mail", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        recipients: form.recipients.split("\n").map(r => r.trim()).filter(r => r !== "")
      })
    });

    const data = await res.json();
    setStatus(data.success ? "success" : "failed");
    alert(data.message);
  };

  return (
    <div className="p-6 bg-white text-black min-h-screen">
      <h1 className="text-2xl mb-4">📧 Bulk Mail Launcher</h1>

      <input name="senderName" placeholder="Sender Name" onChange={handleChange} className="border p-2 mb-2 w-full" />
      <input name="senderMail" placeholder="Sender Mail ID" onChange={handleChange} className="border p-2 mb-2 w-full" />
      <input type="password" name="appPassword" placeholder="App Password" onChange={handleChange} className="border p-2 mb-2 w-full" />
      <input name="subject" placeholder="Subject Line" onChange={handleChange} className="border p-2 mb-2 w-full" />
      <textarea name="message" placeholder="Message Body" onChange={handleChange} className="border p-2 mb-2 w-full h-24" />
      <textarea name="recipients" placeholder="Bulk Mail IDs (one per line)" onChange={handleChange} className="border p-2 mb-2 w-full h-32 resize-y" />

      <p className="text-sm text-gray-600">Count: {form.recipients.split("\n").filter(r => r.trim() !== "").length}</p>

      <button
        onClick={sendMail}
        className={`p-2 rounded w-full mt-3 ${status === "sending" ? "bg-yellow-500" : "bg-black text-white"}`}
      >
        {status === "sending" ? "Sending..." : "Send Mails"}
      </button>
    </div>
  );
}
