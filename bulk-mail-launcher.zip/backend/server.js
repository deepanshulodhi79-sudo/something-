const express = require("express");
const nodemailer = require("nodemailer");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// 🔒 Hardcore login
const ADMIN_USER = "admin";
const ADMIN_PASS = "password123";

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    return res.json({ success: true });
  }
  res.status(401).json({ success: false, message: "Invalid credentials" });
});

// 📧 Bulk mail sending
app.post("/send-mail", async (req, res) => {
  const { senderName, senderMail, appPassword, subject, message, recipients } = req.body;

  try {
    let transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: senderMail,
        pass: appPassword,
      },
    });

    for (let email of recipients) {
      await transporter.sendMail({
        from: `"${senderName}" <${senderMail}>`,
        to: email, // ✅ हर email अलग से जाएगा
        subject,
        text: message,
      });
    }

    res.json({ success: true, message: "✅ All mails sent successfully!" });
  } catch (err) {
    res.status(500).json({ success: false, message: "❌ Mail sending failed", error: err.message });
  }
});

app.listen(5000, () => console.log("🚀 Backend running on port 5000"));
